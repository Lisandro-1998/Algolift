# Algolift — Deployment Guide

Diese Files in dein GitHub Repo (`Lisandro-1998/Algolift`) hochladen, dann deployt Cloudflare Pages automatisch.

---

## 📁 Welche Files wohin (im Repo)

Im Ordner **`algolift-site/`** (oder im Root, je nachdem was dein Cloudflare Pages Build als Output-Verzeichnis hat):

| Datei | Status | Beschreibung |
|-------|--------|--------------|
| `index.html` | **ERSETZEN** | = `algolift-final.html` umbenannt |
| `founders.webp` | **NEU** | Foto von dir und Paul |
| `impressum.html` | **NEU** | DSGVO Impressum |
| `datenschutz.html` | **NEU** | DSGVO Datenschutz |
| `robots.txt` | **NEU** | mit AI-Bot-Allow |
| `sitemap.xml` | **NEU** | für Google Search Console |
| `favicon.png` | bleibt | hast du schon |
| `download.webm` | **LÖSCHEN** | Hero-Video weg, Aurora-Shader ersetzt es |
| `apple-touch-icon.png` | **NEU** | 180×180 PNG für iOS — kannst du erstmal vom favicon ableiten |
| `og-image.jpg` | **NEU** | 1200×630 JPG für Social Shares (Twitter/LinkedIn) |

---

## 🚀 Schritt-für-Schritt Upload

1. **Auf GitHub:** `Lisandro-1998/Algolift` → Branch `main` → Ordner `algolift-site/`

2. **Alte `index.html` ersetzen:**
   - Klick auf alte `index.html` → Edit (Stift-Icon)
   - Inhalt löschen
   - Inhalt von `algolift-final.html` reinkopieren
   - Commit "Update index.html — production ready"

3. **Neue Files hochladen:**
   - `Add file` → `Upload files`
   - Hochziehen: `founders.webp`, `impressum.html`, `datenschutz.html`, `robots.txt`, `sitemap.xml`
   - Commit "Add legal pages, sitemap, founder photo"

4. **Alte `download.webm` löschen:**
   - Klick auf `download.webm` → Trash-Icon → Delete file
   - Commit "Remove unused hero video"

5. **Cloudflare Pages** deployt automatisch (~1-2 Minuten).

---

## ⚠️ Was du noch SELBER erstellen musst

### 1. og-image.jpg (1200×630, JPG, max 5MB)

Das Bild das in Twitter/LinkedIn/Facebook-Previews erscheint wenn jemand deinen Link teilt.

**Schnelle Variante:** Screenshot vom Hero deiner Site machen, in Photoshop/Canva auf 1200×630 zuschneiden, JPG speichern.

**Premium-Variante:** Eigenes Visual mit Logo + Tagline + CTA — z.B. "ALGOLIFT — Reichweite ohne Ad-Budget — algolift.de"

### 2. apple-touch-icon.png (180×180, PNG)

Icon das auf iPhones erscheint wenn jemand deine Site als "Zum Home-Bildschirm hinzufügen" speichert. Kann das gleiche Motiv wie favicon.png sein, nur größer.

---

## ✅ Nach dem Deploy

1. **Site testen** auf [algolift.de](https://algolift.de)
2. **Sitemap einreichen:** Google Search Console → Sitemaps → `https://algolift.de/sitemap.xml`
3. **Lighthouse-Audit** in Chrome DevTools (Mobile + Desktop)
4. **Cookie-Banner testen** — DSGVO-Verhalten checken
5. **Tastatur-Navigation** — Tab durch alle Sections, ESC für FAQ-Akkordeons

---

## 🎯 Was bereits drin und perfekt ist

- ✅ Title 48 chars, Description 128 chars
- ✅ 5 JSON-LD Blocks (Organization, ProfessionalService, FAQPage, WebSite, BreadcrumbList)
- ✅ 10 Open Graph + 5 Twitter Card Tags
- ✅ Canonical Tag → algolift.de
- ✅ Cookie-Banner DSGVO-konform (granular Notwendig/Statistik/Marketing)
- ✅ AI-Bots in robots.txt explizit erlaubt (GPTBot, ClaudeBot, PerplexityBot)
- ✅ 4 Calendly-Touchpoints (Nav, Hero-Buttons, Sticky Mini-CTA, CTA-Section)
- ✅ Sticky Mini-CTA: "3 von 8 — Slot sichern"
- ✅ Reduced-Motion handling (CSS + JS)
- ✅ color-scheme: dark (intentional Brand-Decision)
- ✅ Three.js + Aurora-Shader Performance (DPR 1.25, Sphere 40×40, Page-Visibility-API)
- ✅ Foto integriert + WebP-komprimiert (37KB)
- ✅ Cloudflare als Hoster im Datenschutz angegeben

---

**Stand:** Mai 2026
